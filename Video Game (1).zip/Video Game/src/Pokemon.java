public class Pokemon extends VideoGame{
    private String character, firstPokemon;
    private int pokemonCount;

    public Pokemon(String name, int yearReleased, double rating, String character, String firstPokemon, int pokemonCount){
        super(name, yearReleased, rating);
        this.character = character;
        this.firstPokemon = firstPokemon;
        this.pokemonCount = pokemonCount;
    }

    public String getCharacterName(){
        return character;
    }
    public String getFirstPokemon(){
        return firstPokemon;
    }
    public int getPokemonCount(){
        return pokemonCount;
    }

    public void findPokemon(){
        System.out.println("You found a new Pokemon! +1");
        pokemonCount++;
    }

    public void fight(){
        int x = (int)(Math.random() * 3);
        if (x == 0){
            System.out.println("You won a battle! You win two new Pokemon! +2");
            pokemonCount++;
            pokemonCount++;
        }
        if (x == 1){
            System.out.println("You barely defeat your opponent. You win a Pokemon. +1");
            pokemonCount++;
        }
        if (x == 2){
            System.out.println("You lose this match. You lose a Pokemon. Better luck next time!");
            pokemonCount--;
        }
    }
}
