public class VideoGame {

    private String name;
    private int yearReleased;
    private double rating;

    public VideoGame(String name, int yearReleased, double rating){
        this.name = name;
        this.yearReleased = yearReleased;
        this.rating = rating;
    }

    public String getName(){
        return name;
    }
    public int getYearReleased(){
        return yearReleased;
    }
    public double getRating(){
        return rating;
    }

    public void tryGame() throws InterruptedException{
        System.out.println("Opening " + name + "... ");
        Thread.sleep(1000);
        System.out.println("Playing " + name + "!");
        Thread.sleep(400);
        System.out.println("Game over!");
    }

    public void leaveReview(String username, String review){
        System.out.println("Left your review! \n     \"" + review + "\"\n    -" + username);
    }
}
