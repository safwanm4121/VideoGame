public class CallOfDuty extends VideoGame{
    private String primary, secondary;
    private int gamesWon, aimValue, kills, assists, deaths;
    private boolean KDAratio; // Whether your KDA ratio is over 1.5

    public CallOfDuty(String name, int yearReleased, double rating, String primary, String secondary, int gamesWon){
        super(name, yearReleased, rating);
        this.primary = primary;
        this.secondary = secondary;
        this.gamesWon = gamesWon;
        this.kills = 0;
        this.assists = 0;
        this.deaths = 0;
        this.KDAratio = false;
        this.aimValue = 0;
    }

    public CallOfDuty(String name, int yearReleased, double rating, String primary, String secondary, int gamesWon, int kills, int assists, int deaths){
        super(name, yearReleased, rating);
        this.primary = primary;
        this.secondary = secondary;
        this.gamesWon = gamesWon;
        this.kills = kills;
        this.assists = assists;
        this.deaths = deaths;
        this.KDAratio = false;
        if ((double)(kills + assists)/deaths >= 1.5){
            this.KDAratio = true;
        }
    }

    public String getPrimary(){
        return primary;
    }
    public String getSecondary(){
        return secondary;
    }
    public int getGamesWon(){
        return gamesWon;
    }
    public boolean isKDHigh(){
        return KDAratio;
    }
    public int getAimValue(){
        return aimValue;
    }
    public int getKills(){
        return kills;
    }
    public int getAssists() {
        return assists;
    }
    public int getDeaths(){
        return deaths;
    }
    public double getKDA(){
        return ((double)(kills + assists)/deaths);
    }

    public void practiceAim(){
        System.out.println("Practicing aim at the shooting range! +1 aim!");
        aimValue++;
    }

    public void checkKDA(){
        if (kills == 0){
            System.out.println("You have no kills!");
        }
        else if (deaths != 0 && (double)(kills + assists)/deaths >= 1.5){
            this.KDAratio = true;
            System.out.println("Your KDA ratio is " + (double)(kills + assists)/deaths);
        }
        else if (deaths == 0){
            System.out.println("Your KDA ratio is " + (kills+ assists));
        }
    }

    public void playMatch(){
        int kills1, assists1, deaths1;
        int x = (int)(Math.random() * 3);
        if (x == 0){
            kills1 = (int)((Math.random() * 10)+15);
            assists1 = (int)((Math.random() * 5));
            deaths1 = (int)((Math.random() * 4)+2);
            System.out.println("You played well! You got:");
            System.out.println(kills1 + " kills");
            System.out.println(assists1 + " assists");
            System.out.println(deaths1 + " deaths");
            System.out.println("" + (double)(kills1 + assists1)/deaths1+ " KDA");
            kills += kills1;
            assists += assists1;
            deaths += deaths1;
        }
        if (x == 1){
            kills1 = (int)((Math.random() * 5)+5);
            assists1 = (int)((Math.random() * 2));
            deaths1 = (int)((Math.random() * 8)+4);
            System.out.println("Yikes. That KD is suffering. You got:");
            System.out.println(kills1 + " kills");
            System.out.println(assists1 + " assists");
            System.out.println(deaths1 + " deaths");
            System.out.println("" + (double)(kills1 + assists1)/deaths1+ " KDA");
            kills += kills1;
            assists += assists1;
            deaths += deaths1;
        }
        if (x == 2){
            kills1 = (int)((Math.random() * 7)+10);
            assists1 = (int)((Math.random() * 3));
            deaths1 = (int)((Math.random() * 2)+2);
            System.out.println("You played alright. You got:");
            System.out.println(kills1 + " kills");
            System.out.println(assists1 + " assists");
            System.out.println(deaths1 + " deaths");
            System.out.println("" + (double)(kills1 + assists1)/deaths1+ " KDA");
            kills += kills1;
            assists += assists1;
            deaths += deaths1;
        }
    }
}
