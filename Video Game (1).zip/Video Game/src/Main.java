public class Main {
    public static void main(String[] args) {
        CallOfDuty BlackOps = new CallOfDuty("Black Ops III", 2015, 9.2, "KN-44", "1911", 21, 309, 45, 79);
        System.out.println(BlackOps.getName());
        System.out.println(BlackOps.getYearReleased());
        System.out.println("High KDA: " + BlackOps.isKDHigh());
        BlackOps.checkKDA();
        BlackOps.playMatch();
        BlackOps.checkKDA();

        System.out.println();
        Pokemon Ash = new Pokemon("X and Y", 2013, 9.4, "Ash", "Pikachu", 13);
        System.out.println(Ash.getName());
        System.out.println(Ash.getYearReleased());
        System.out.println(Ash.getCharacterName());
        System.out.println("You have " + Ash.getPokemonCount() + " pokemons.");
        Ash.fight();
        Ash.fight();
        Ash.fight();
        System.out.println("You have " + Ash.getPokemonCount() + " pokemons.");
    }
}
